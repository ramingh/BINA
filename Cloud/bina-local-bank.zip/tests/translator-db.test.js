/* مترجم و دیتابیس: مستقل از نسخه، بدون حساسیت به حروف، علت واقعی خطا، بستن اتصال */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');
const { indexedDB, IDBKeyRange } = require('fake-indexeddb');

const dom = new JSDOM('<!doctype html><html><body></body></html>', { runScripts: 'outside-only', url: 'http://localhost/' });
const w = dom.window;
w.indexedDB = indexedDB; w.IDBKeyRange = IDBKeyRange;
w.eval(fs.readFileSync(path.join(__dirname, '../app/Dic_sek.Js'), 'utf8') + '\n;window.WebTranslator = WebTranslator;');
w.console.log = () => {};
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
const open = (name, ver, stores) => new Promise((res, rej) => {
  const q = indexedDB.open(name, ver);
  q.onupgradeneeded = () => stores.forEach(s => q.result.createObjectStore(s));
  q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error);
});
const put = (db, store, key, val) => new Promise((res, rej) => {
  const tx = db.transaction(store, 'readwrite'); tx.objectStore(store).put(val, key);
  tx.oncomplete = res; tx.onerror = () => rej(tx.error);
});
const seed = async (name, ver, store) => {
  const db = await open(name, ver, [store, 'catalog']);
  await put(db, store, ['TK_Dic_FieldName', 1], ['Debit', 1, 'بدهکار', 1]);
  await put(db, store, ['TK_Dic_FieldName', 2], ['Credit', 1, 'بستانکار', 2]);
  db.close();
};
const T = (...a) => new w.WebTranslator(...a);
const opts = { cacheEnabled: false };
const deletes = name => new Promise(res => {
  const t = setTimeout(() => res('blocked/timeout'), 500);
  const q = indexedDB.deleteDatabase(name); q.onsuccess = () => { clearTimeout(t); res('deleted'); }; q.onerror = () => { clearTimeout(t); res('error'); };
});

(async () => {
  await seed('public', 4, 'tk_dic');                 /* همان بانک کاربر: نسخهٔ 4، نام‌های lowercase */

  let t = T(undefined, undefined, undefined, opts);
  ok(t.dbName === 'public' && t.storeName === 'tk_dic' && t.dbVersion === null, 'پیش‌فرض‌ها: public / tk_dic / بدون نسخه');
  ok(await t.init() === true && t.dictionaries.en['بدهکار'] === 'Debit' && t.dictionaries.en['بستانکار'] === 'Credit', 'نسخهٔ 4 بدون dbVersion باز و دیکشنری بارگذاری شد');

  t = T('Public', 'TK_Dic', null, opts);
  ok(await t.init() === true && t.dictionaries.en['بدهکار'] === 'Debit', 'نام‌های قدیمی (Public/TK_Dic) هم تطبیق داده می‌شود');

  /* سناریوی خطای کاربر: نسخهٔ سخت‌کدشدهٔ 3 روی بانک نسخهٔ 4 */
  t = T('public', 'tk_dic', 3, opts);
  let err = null; try { await t.init(); } catch (e) { err = e; }
  ok(err && /VersionError/.test(err.message) && /null/.test(err.message), 'dbVersion=3 روی بانک نسخهٔ 4: پیام علت واقعی: ' + (err && err.message));

  /* نسخهٔ بالاتر بعداً (9) هم مشکلی ندارد */
  await seed('public9', 9, 'TK_dic');
  t = T('public9', 'tk_dic', null, opts);
  ok(await t.init() === true && t.dictionaries.en['بدهکار'] === 'Debit', 'نسخهٔ 9 و استور TK_dic (حروف متفاوت) هم کار می‌کند');

  /* استور وجود ندارد → false بدون خطا */
  const nd = await open('nostore', 2, ['other']); nd.close();
  t = T('nostore', 'tk_dic', null, opts);
  ok(await t.init() === false, 'استور ناموجود: false (بدون throw)');


  /* بانک lowercase شده: کلید ردیف‌ها هم lowercase است ('tk_dic_fieldname') */
  const lk = await open('lowkeys', 4, ['tk_dic']);
  await put(lk, 'tk_dic', ['tk_dic_fieldname', 1], ['Debit', 1, 'بدهکار', 1]);
  await put(lk, 'tk_dic', ['tk_dic_fieldname', 2], ['مدين', 2, 'بدهکار', 2]); lk.close();
  t = T('lowkeys', 'tk_dic', null, opts);
  ok(await t.init() === true && t.dictionaries.en['بدهکار'] === 'Debit' && t.dictionaries.ar['بدهکار'] === 'مدين', 'کلید lowercase (tk_dic_fieldname) پذیرفته شد (en و ar)');

  /* تشخیص: رکوردها هست ولی هیچ‌کدام معتبر نیست → هشدار با نمونه */
  const warns = []; w.console.warn = (...a) => warns.push(a.join(' '));
  const bk = await open('badrows', 4, ['tk_dic']);
  await put(bk, 'tk_dic', ['other_key', 1], ['Debit', 1, 'بدهکار', 1]);
  await put(bk, 'tk_dic', 'plain', { not: 'array' }); bk.close();
  t = T('badrows', 'tk_dic', null, opts);
  await t.init();
  ok(warns.some(x => /هیچ‌کدام معتبر نبود/.test(x) && /"key"/.test(x) && /"why"/.test(x)), 'رکورد نامعتبر: هشدار با نمونه‌ی رکورد: ' + (warns[0] || '').slice(0, 90));

  /* تشخیص: استور خالی */
  warns.length = 0;
  const ek = await open('emptystore', 4, ['tk_dic']); ek.close();
  t = T('emptystore', 'tk_dic', null, opts); await t.init();
  ok(warns.some(x => /خالی است/.test(x)), 'استور خالی: هشدار');

  /* تشخیص: setLanguage با دیکشنری خالی هشدار می‌دهد */
  warns.length = 0;
  await t.setLanguage('en');
  ok(warns.some(x => /دیکشنری 'en' خالی است/.test(x)), "setLanguage روی دیکشنری خالی: هشدار");


  /* بانک بازسازی‌شدهٔ کاربر: رکورد آبجکتی {FieldName, Caption, CountryCode, Id} با کلید عددی (نمونهٔ واقعی از کنسول کاربر) */
  const ob = await open('objrec', 4, ['tk_dic']);
  await put(ob, 'tk_dic', 1, { key: 1, CountryCode: 2, FieldName: 'اسناد حسابداری شرکتها', Caption: 'Company Accounting Documents', Id: 1 });
  await put(ob, 'tk_dic', 2, { key: 2, CountryCode: 3, FieldName: 'اسناد حسابداری شرکتها', Caption: 'المستندات المحاسبية للشركات', Id: 2 });
  await put(ob, 'tk_dic', 3, { key: 3, CountryCode: 2, FieldName: 'ارزیابی عملکرد', Caption: 'Performance Evaluation', Id: 3 });
  await put(ob, 'tk_dic', 4, { key: 4, CountryCode: 2, FieldName: 'بدون ترجمه', Caption: '', Id: 4 });
  ob.close();
  warns.length = 0;
  t = T('objrec', 'tk_dic', null, opts);
  ok(await t.init() === true && Object.keys(t.dictionaries.en).length === 2 && Object.keys(t.dictionaries.ar).length === 1, 'رکورد آبجکتی: en=2 ، ar=1 (رکورد با Caption خالی رد شد)');
  ok(t.dictionaries.en['اسناد حسابداری شرکتها'] === 'Company Accounting Documents' && t.dictionaries.ar['اسناد حسابداری شرکتها'] === 'المستندات المحاسبية للشركات', 'CountryCode 2=انگلیسی و 3=عربی');
  ok(!warns.some(x => /هیچ‌کدام معتبر نبود/.test(x)), 'دیگر هشدار «هیچ‌کدام معتبر نبود» نیست');
  w.document.body.innerHTML = '<nav id="m"><span id="s1">اسناد حسابداری شرکت‌ها</span><span id="s2">ارزیابی عملکرد</span><span id="s3">متن ناشناخته</span></nav>';
  await t.setLanguage('en');
  ok(w.document.getElementById('s1').textContent === 'Company Accounting Documents' && w.document.getElementById('s2').textContent === 'Performance Evaluation', 'منو به انگلیسی ترجمه شد (حتی با نیم‌فاصلهٔ متفاوت «شرکت‌ها»/«شرکتها»)');
  ok(w.document.getElementById('s3').textContent === 'متن ناشناخته', 'متن بدون ورودی دست‌نخورده');
  await t.setLanguage('ar');
  ok(w.document.getElementById('s1').textContent === 'المستندات المحاسبية للشركات', 'منو به عربی ترجمه شد');
  await t.setLanguage('fa');
  ok(w.document.getElementById('s1').textContent === 'اسناد حسابداری شرکت‌ها', 'برگشت به فارسی: متن اصلی');
  t._stopObserver();

  /* اتصال بسته می‌شود تا ارتقای بعدی بانک بلوکه نشود */
  ok(await deletes('public9') === 'deleted', 'بعد از init اتصال بسته است (deleteDatabase بلوکه نشد)');
  console.log('done'); process.exit(process.exitCode || 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
