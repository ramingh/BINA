BINA - Bina15_1 accounting documents browser v1.1 (2026-11-10)

Source files follow the codes in Sidbar.xlsx: 15-1 -> Bina15_1.html/.js/.css.

This is an INCREMENTAL UPDATE ZIP, not the full BINA repository.
To test locally:
1) Extract this ZIP into your existing project ROOT, preserving the FINAL/... paths.
2) Replace FINAL/side_bar.html when prompted.
3) Continue to use the project's existing shared libraries, public IndexedDB and local web-server origin.
4) Open FINAL/side_bar.html from the SAME web-server origin previously used to populate IndexedDB.
5) Select 'اسناد حسابداری' under 'اسناد و مرور حسابها'.

The following OLD form-specific files are no longer used:
 FINAL/pages/tab-16.html
 FINAL/app/bina/BinaSanadBrowser.js
 FINAL/css/SanadBrowser.css
They can be removed from your local project; do not remove any shared BINA library.

No font files are bundled. Use the font already available in the root of your project.
GitHub source revision: 48f60e52e85d0925bd52da47903efdea97b398aa
