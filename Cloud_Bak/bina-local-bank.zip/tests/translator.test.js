/* تست مترجم: translate="no" دست‌نخورده می‌ماند؛ عنوان‌ها (بیرون از آن) ترجمه می‌شوند — هم در پیمایش اول هم در observer */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const dom = new JSDOM('<!doctype html><html><body></body></html>', { runScripts: 'outside-only', url: 'http://localhost/' });
const w = dom.window;
w.eval(fs.readFileSync(path.join(__dirname, '../app/Dic_sek.Js'), 'utf8') + '\n;window.WebTranslator = WebTranslator;');
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const origLog = w.console.log; w.console.log = () => {};
  const t = new w.WebTranslator('Public', 'TK_Dic', 3, { cacheEnabled: false });
  t.dictionaries.en = { 'بدهکار': 'Debit', 'بستانکار': 'Credit', 'جستجو': 'Search' };
  w.document.body.innerHTML =
    '<div id="head"><span id="h1">بدهکار</span><input id="inp" placeholder="جستجو"></div>' +
    '<div id="body" translate="no"><span id="c1">بدهکار</span><b><i id="c2">بستانکار</i></b><input id="cin" placeholder="جستجو"></div>' +
    '<div class="notranslate"><span id="n1">بدهکار</span></div>';
  const $ = id => w.document.getElementById(id);

  await t.setLanguage('en');
  ok($('h1').textContent === 'Debit', 'خارج از ناحیه ترجمه شد: ' + $('h1').textContent);
  ok($('inp').getAttribute('placeholder') === 'Search', 'placeholder بیرون ترجمه شد');
  ok($('c1').textContent === 'بدهکار' && $('c2').textContent === 'بستانکار', 'داخل translate="no" (تو در تو) دست‌نخورده');
  ok($('cin').getAttribute('placeholder') === 'جستجو', 'attribute داخل translate="no" دست‌نخورده');
  ok($('n1').textContent === 'بدهکار', 'کلاس .notranslate هم رعایت شد');

  /* observer: گره‌های اضافه‌شده بعد از تغییر زبان */
  const h2 = w.document.createElement('span'); h2.textContent = 'بستانکار'; $('head').append(h2);
  const c3 = w.document.createElement('span'); c3.textContent = 'بستانکار'; $('body').append(c3);
  const row = w.document.createElement('div'); row.innerHTML = '<span>بدهکار</span>'; $('body').append(row);
  await sleep(30);
  ok(h2.textContent === 'Credit', 'observer: گرهٔ جدید بیرون ترجمه شد');
  ok(c3.textContent === 'بستانکار' && row.textContent === 'بدهکار', 'observer: گره‌های جدید داخل translate="no" دست‌نخورده');

  /* تغییر متن موجود (characterData) داخل ناحیه */
  $('c1').firstChild.nodeValue = 'بستانکار';
  await sleep(30);
  ok($('c1').textContent === 'بستانکار', 'characterData داخل ناحیه دست‌نخورده');

  /* برگشت به فارسی: بیرون برمی‌گردد، داخل همان است */
  await t.setLanguage('fa');
  ok($('h1').textContent === 'بدهکار' && h2.textContent === 'بستانکار', 'برگشت به fa: بیرون به متن اصلی');

  /* گزینهٔ غیرفعال‌سازی: noTranslateSelector خالی → رفتار قدیمی (همه ترجمه شود) */
  const t2 = new w.WebTranslator('Public', 'TK_Dic', 3, { cacheEnabled: false, noTranslateSelector: '' });
  t2.dictionaries.en = { 'بدهکار': 'Debit' };
  await t2.setLanguage('en');
  w.document.body.innerHTML = '<div translate="no"><span id="z">بدهکار</span></div>';
  await t2.setLanguage('en');
  ok(w.document.getElementById('z').textContent === 'Debit', 'noTranslateSelector="" = رفتار قبلی (ترجمهٔ همه)');
  w.console.log = origLog;
  t._stopObserver(); t2._stopObserver();
  console.log('done');
})().catch(e => { console.error('CRASH', e); process.exit(1); });
