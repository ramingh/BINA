/* BinaTabFrames: iframe زنده برای هر تب، حفظ حالت، سقف تب زنده و انجماد/بازسازی */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');
const dom = new JSDOM('<!doctype html><html><body><div id="box"></div></body></html>', { runScripts: 'outside-only', pretendToBeVisual: true, url: 'http://localhost/' });
const w = dom.window;
w.eval(fs.readFileSync(path.join(__dirname, '../app/bina/bina-tabs.js'), 'utf8'));
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const box = w.document.getElementById('box');
const visible = f => !f.hidden && f.style.display !== 'none';
const fake = (frame, key) => { frame.contentWindow.BinaPage = { shown: 0, getState: () => ({ key, n: 7 }), onShow() { this.shown++; } }; };

(async () => {
  const fr = new w.BinaTabFrames(box, { maxLive: 2 });
  fr.open('k1', 'pages/a.html'); fr.open('k2', 'pages/b.html');
  const f1 = fr.liveFrames()[0], f2 = fr.liveFrames()[1];
  fake(f1, 'k1'); fake(f2, 'k2');
  fr.activate('k1');
  ok(visible(f1) && !visible(f2), 'k1 دیده می‌شود، k2 مخفی (hidden + display:none)');
  const iframeK1 = f1;
  fr.activate('k2'); fr.activate('k1');
  ok(fr.liveFrames().includes(iframeK1) && iframeK1.parentNode === box, 'برگشتن به k1: همان iframe (حالت صفحه حفظ شد، reload نشد)');
  await sleep(40);
  ok(f1.contentWindow.BinaPage.shown >= 2, 'onShow (redraw) هنگام نمایش دوباره صدا زده شد: ' + f1.contentWindow.BinaPage.shown);

  /* سقف: تب سوم → قدیمی‌ترین غیرفعال منجمد می‌شود */
  fr.open('k3', 'pages/c.html');
  const f3 = fr.liveFrames().find(f => f !== f1 && f !== f2); fake(f3, 'k3');
  fr.activate('k3');
  ok(fr.liveFrames().length === 2, 'سقف ۲ تب زنده رعایت شد');
  ok(fr.isFrozen('k2') && !fr.isFrozen('k1') && !fr.isFrozen('k3'), 'k2 (قدیمی‌ترین غیرفعال) منجمد شد');
  ok(!box.contains(f2), 'iframe منجمد از DOM حذف شد (رم آزاد)');

  /* بازسازی تب منجمد */
  fr.activate('k2');
  const nf2 = fr.liveFrames().find(f => f.title === 'k2');
  ok(nf2 && nf2 !== f2 && visible(nf2), 'k2 با iframe تازه بازسازی شد');
  ok(nf2.__binaState && nf2.__binaState.key === 'k2' && nf2.__binaState.n === 7, 'حالت ذخیره‌شده به iframe تازه داده شد: ' + JSON.stringify(nf2.__binaState));
  ok(fr.liveFrames().length === 2 && fr.isFrozen('k1') !== fr.isFrozen('k3'), 'باز هم سقف رعایت شد (یکی دیگر منجمد شد)');
  ok(fr.liveFrames().filter(visible).length === 1, 'فقط یک تب دیده می‌شود');

  /* تب فعال هرگز منجمد نمی‌شود، حتی با maxLive=1 */
  const f1b = new w.BinaTabFrames(w.document.createElement('div'), { maxLive: 1 });
  f1b.open('a', 'a.html'); f1b.open('b', 'b.html'); f1b.activate('b'); f1b.activate('a');
  ok(f1b.liveFrames().length === 1 && !f1b.isFrozen('a'), 'maxLive=1: تب فعال زنده می‌ماند');

  /* freeze وقتی BinaPage هنوز mount نشده: حالت قبلی نمی‌پرد */
  const fz = new w.BinaTabFrames(w.document.createElement('div'), { maxLive: 1 });
  fz.open('p', 'p.html'); fz.open('q', 'q.html'); fz.activate('p'); fz.activate('q');
  ok(fz.isFrozen('p'), 'بدون BinaPage هم انجماد خطا نمی‌دهد');

  /* بستن */
  fr.close('k3');
  ok(!fr.has('k3') && !fr.liveFrames().some(f => f.title === 'k3'), 'close: تب و iframe حذف شد');
  fr.closeAll();
  ok(box.children.length === 0 && !fr.has('k1'), 'closeAll: همه حذف شد');
  fr.activate('');
  ok(fr.liveFrames().length === 0, 'activate("") بدون تب خطا نمی‌دهد');
  console.log('done'); process.exit(process.exitCode || 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
