/* تست دودی shell: side_bar.html و app.js (نسخهٔ اصلاح‌شده) در jsdom — منو، تب‌ها، iframeهای زنده، زبان */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

let html = fs.readFileSync(path.join(__dirname, '../app/side_bar.html'), 'utf8');
const inline = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]).filter(t => /languagePopup/.test(t) && /BinaFrames/.test(t))[0];
html = html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<link[^>]*>/g, '');
const dom = new JSDOM(html, { runScripts: 'outside-only', pretendToBeVisual: true, url: 'http://localhost/side_bar.html' });
const w = dom.window;
w.Element.prototype.scrollIntoView = function () {};
w.eval(fs.readFileSync(path.join(__dirname, '../app/bina/bina-tabs.js'), 'utf8'));
w.eval(fs.readFileSync(path.join(__dirname, '../app/app.js'), 'utf8'));
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const $ = s => w.document.querySelector(s);
const click = el => el.dispatchEvent(new w.MouseEvent('click', { bubbles: true, cancelable: true }));
const frames = () => [...w.document.querySelectorAll('#contentFrames iframe')];
const visible = f => !f.hidden && f.style.display !== 'none';

(async () => {
  ok(!$('#contentFrame') && $('#contentFrames'), 'iframe مشترک قدیمی نیست؛ کانتینر #contentFrames هست');
  ok(w.BinaFrames && typeof w.BinaFrames.activate === 'function', 'window.BinaFrames ساخته شد');
  const leaf = href => $('.sidebar-menu a.menu-item[href="' + href + '"]');
  const a = leaf('pages/tab-13.html'), b = leaf('pages/tab-14.html'), c = leaf('pages/tab-15.html');
  ok(a && b && c, 'برگ‌های منو پیدا شد (tab-13/14/15)');

  click(a);
  ok(frames().length === 1 && frames()[0].getAttribute('src') === 'pages/tab-13.html' && visible(frames()[0]), 'کلیک برگ: یک iframe با src صفحه');
  ok($('#contentWelcome').hidden === true && w.document.querySelectorAll('#tabList .tab').length === 1, 'پیام خوشامد مخفی، یک تب باز');
  const f13 = frames()[0];
  click(b);
  ok(frames().length === 2 && !visible(f13) && visible(frames()[1]), 'تب دوم: iframe اولی مخفی (نه حذف) و دومی دیده می‌شود');
  click(a);
  ok(frames().length === 2 && frames()[0] === f13 && visible(f13), 'برگشت به تب اول: همان iframe (reload نشد)');
  click(a);
  ok(frames().length === 2 && w.document.querySelectorAll('#tabList .tab').length === 2, 'کلیک دوباره روی همان منو: تب/iframe تکراری ساخته نشد');

  /* کلیک روی تب (نه منو) */
  const tabs = [...w.document.querySelectorAll('#tabList .tab')];
  click(tabs[1]);
  ok(visible(frames()[1]) && !visible(frames()[0]), 'کلیک روی نوار تب‌ها هم جابه‌جا می‌کند');

  /* سقف تب‌های زنده از طریق shell (۸) */
  const leaves = [...w.document.querySelectorAll('.sidebar-menu a.menu-item')].slice(0, 11);
  leaves.forEach(l => click(l));
  await sleep(20);
  ok(w.BinaFrames.liveFrames().length <= 8, 'سقف ۸ تب زنده: ' + w.BinaFrames.liveFrames().length + ' از ' + w.document.querySelectorAll('#tabList .tab').length + ' تب');
  ok(w.BinaFrames.liveFrames().filter(visible).length === 1, 'فقط تب فعال دیده می‌شود');

  /* بستن تب */
  const before = w.document.querySelectorAll('#tabList .tab').length;
  click(w.document.querySelector('#tabList .tab--active .tab__close'));
  ok(w.document.querySelectorAll('#tabList .tab').length === before - 1, 'بستن تب فعال: یک تب کم شد');

  /* زبان: همهٔ تب‌های زنده ترجمه شوند (اسکریپت inline اصلاح‌شدهٔ side_bar.html) */
  const calls = [];
  w.WebTranslator = class { async init() {} setLanguage(l) { calls.push('shell:' + l); } };
  w.BinaFrames.liveFrames().forEach((f, i) => { f.contentWindow.translator = { setLanguage: l => calls.push('frame' + i + ':' + l) }; });
  w.eval(inline);
  const en = w.document.querySelector('#languagePopup [data-language="en"]');
  click(en);
  const live = w.BinaFrames.liveFrames().length;
  ok(calls.filter(x => x.startsWith('frame')).length === live && live > 1, 'زبان en روی همهٔ ' + live + ' تب زنده اعمال شد');
  ok(calls.includes('shell:en'), 'مترجم shell هم صدا زده شد');

  /* بستن همه */
  click($('#closeAllTabsButton'));
  ok(frames().length === 0 && $('#contentWelcome').hidden === false, 'بستن همه: iframeها حذف، پیام خوشامد برگشت');

  /* بقیهٔ قابلیت‌های app.js دست‌نخورده: تم/سایدبار */
  click($('#themeButton'));
  ok(w.document.documentElement.dataset.theme === 'dark', 'دکمهٔ تم هنوز کار می‌کند');
  click($('#sidebarToggleButton'));
  ok($('.app-layout').classList.contains('is-sidebar-collapsed'), 'جمع/باز کردن سایدبار هنوز کار می‌کند');
  console.log('done'); process.exit(process.exitCode || 0);
})().catch(e => { console.error('CRASH', e); process.exit(1); });
